console.log("Server started");

let server = require("./mainPage.js");

server.start();
console.log("Server up and running");